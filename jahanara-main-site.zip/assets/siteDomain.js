const siteDomain = "www.jahanaraschool.ir";
export default siteDomain;