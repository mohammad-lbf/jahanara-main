const data = [
    {
        id:60041,
        name:"درسنامه فصل 2 کسر ریاضی ششم",
        caption:"درسنامه فصل 2 کسر ریاضی - پایه ششم دبستان",
        creator:"جناب آقای محمد لبافی",
        upoledDate:"1403/08/20",
        fileType:"PDF",
        src:"/Files/hamyar/sheshom/darsnameh/درسنامه-فصل-2-کسر-ریاضی-(سری4)-ششم-دبستان.pdf",
        book:"riazi",
        boolInP:"ریاضی",
        gradeInP:"پایه ششم",
        image:"/images/hamyar/components/modules/books/sheshom/riazi.jpg",
        slug: "/hamyar/sheshom/darsnameh/60041"
    } , 
    
    

]

export default data