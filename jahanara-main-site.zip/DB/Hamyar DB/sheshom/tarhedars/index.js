const data = [
    {
        id:60021,
        name:"طرح درس سالانه کتاب ریاضی",
        caption:"طرح درس سالانه کتاب ریاضی ششم دبستان",
        creator:"جناب آقای محمد لبافی",
        upoledDate:"1403/08/20",
        fileType:"WORD",
        src:"/Files/hamyar/sheshom/tarhedars/طرح درس سالانه کتاب ریاضی ششم ابتدایی.doc",
        book:"riazi",
        boolInP:"ریاضی",
        gradeInP:"پایه ششم",
        image:"/images/hamyar/components/modules/books/sheshom/riazi.jpg",
        slug: "/hamyar/sheshom/tarhedars/60021"
    } , 
    
    

]

export default data