const data = [
    {
        id:60031,
        name:"جزوه فصل 2 کسر ریاضی",
        caption:"جزوه فصل 2 کسر ریاضی - پایه ششم دبستان",
        creator:"جناب آقای محمد لبافی",
        upoledDate:"1403/08/20",
        fileType:"PDF",
        src:"/Files/hamyar/sheshom/mohtava/جزوه-فصل-2-کسر-ریاضی-(سری5)-ششم-دبستان.pdf",
        book:"riazi",
        boolInP:"ریاضی",
        gradeInP:"پایه ششم",
        image:"/images/hamyar/components/modules/books/sheshom/riazi.jpg",
        slug: "/hamyar/sheshom/mohtava/60031"
    } , 
    
    
    

]

export default data