const data = [
    {
        id:50041,
        name:"درسنامه فصل 2 کسر ریاضی",
        caption:"درسنامه فصل 2 کسر ریاضی — پنجم دبستان",
        creator:"جناب آقای محمد لبافی",
        upoledDate:"1403/08/20",
        fileType:"PDF",
        src:"/Files/hamyar/panjom/darsnameh/درسنامه-فصل-2-کسر-ریاضی-(سری1)-پنجم-دبستان.pdf",
        book:"riazi",
        boolInP:"ریاضی",
        gradeInP:"پایه پنجم",
        image:"/images/hamyar/components/modules/books/panjom/riazi.jpg",
        slug: "/hamyar/panjom/darsnameh/50041"
    } 

]

export default data