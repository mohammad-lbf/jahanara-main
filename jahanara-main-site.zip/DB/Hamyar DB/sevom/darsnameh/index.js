const data = [
    {
        id:30041,
        name:"درسنامه‌ی فصل سوم علوم سوم دبستان(مواد اطراف ما)",
        caption:"درسنامه‌ی فصل سوم علوم(مواد اطراف ما) - پایه سوم",
        creator:"جناب آقای محمد لبافی",
        upoledDate:"1403/08/18",
        fileType:"PDF",
        src:"/Files/hamyar/sevom/darsnameh/درسنامه فصل سوم علوم سوم.pdf",
        book:"oloom",
        boolInP:"علوم",
        gradeInP:"پایه سوم",
        image:"/images/hamyar/components/modules/books/sevom/oloom.jpg",
        slug: "/hamyar/sevom/darsnameh/30041"
    } , 

    
    

]

export default data